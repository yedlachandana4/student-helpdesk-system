import java.util.List;
import java.util.Scanner;

public class Main {

    private static Scanner scanner = new Scanner(System.in);
    private static HelpdeskService service = new HelpdeskService();

    public static void main(String[] args) {

        addSampleData();

        while (true) {

            showMenu();

            int choice = readInt("Enter your choice: ");

            switch (choice) {

                case 1:
                    createTicket();
                    break;

                case 2:
                    updateTicket();
                    break;

                case 3:
                    viewAllTickets();
                    break;

                case 4:
                    viewTicket();
                    break;

                case 5:
                    searchTickets();
                    break;

                case 6:
                    moveToInProgress();
                    break;

                case 7:
                    resolveTicket();
                    break;

                case 8:
                    closeTicket();
                    break;

                case 9:
                    System.out.println("\nThank you for using Student Helpdesk!");
                    scanner.close();
                    return;

                default:
                    System.out.println("\nInvalid choice. Please select 1-9.");
            }
        }
    }

    private static void showMenu() {

        System.out.println("\n========================================");
        System.out.println("        STUDENT HELP DESK SYSTEM");
        System.out.println("========================================");
        System.out.println("1. Create Ticket");
        System.out.println("2. Update Ticket");
        System.out.println("3. View All Tickets");
        System.out.println("4. View Ticket");
        System.out.println("5. Search Tickets");
        System.out.println("6. Mark as In Progress");
        System.out.println("7. Resolve Ticket");
        System.out.println("8. Close Ticket");
        System.out.println("9. Exit");
        System.out.println("========================================");
    }

    private static void createTicket() {

        System.out.println("\n--- CREATE TICKET ---");

        String name = readRequired("Student name: ");
        String title = readRequired("Ticket title: ");
        String description = readRequired("Description: ");

        Category category = selectCategory();
        Priority priority = selectPriority();

        User user = new User(name);

        Ticket ticket = service.createTicket(
                user,
                title,
                description,
                category,
                priority
        );

        System.out.println("\nTicket created successfully!");
        System.out.println("Ticket ID: " + ticket.getTicketId());
    }

    private static void updateTicket() {

        System.out.println("\n--- UPDATE TICKET ---");

        String id = readRequired("Enter Ticket ID: ");

        Ticket ticket = service.findTicket(id);

        if (ticket == null) {
            System.out.println("Ticket not found.");
            return;
        }

        if (ticket.getStatus() == TicketStatus.CLOSED) {
            System.out.println("Closed tickets cannot be updated.");
            return;
        }

        String title = readRequired("New title: ");
        String description = readRequired("New description: ");

        Category category = selectCategory();
        Priority priority = selectPriority();

        boolean updated = service.updateTicket(
                id,
                title,
                description,
                category,
                priority
        );

        if (updated) {
            System.out.println("Ticket updated successfully.");
        } else {
            System.out.println("Unable to update ticket.");
        }
    }

    private static void viewAllTickets() {

        System.out.println("\n--- ALL TICKETS ---");

        List<Ticket> tickets = service.getAllTickets();

        if (tickets.isEmpty()) {
            System.out.println("No tickets available.");
            return;
        }

        for (Ticket ticket : tickets) {
            ticket.displayTicket();
        }
    }

    private static void viewTicket() {

        String id = readRequired("Enter Ticket ID: ");

        Ticket ticket = service.findTicket(id);

        if (ticket == null) {
            System.out.println("Ticket not found.");
        } else {
            ticket.displayTicket();
        }
    }

    private static void searchTickets() {

        System.out.println("\n--- SEARCH TICKETS ---");

        String keyword = readRequired("Enter search keyword: ");

        List<Ticket> results = service.searchTickets(keyword);

        if (results.isEmpty()) {
            System.out.println("No tickets found.");
            return;
        }

        System.out.println("\nSearch results:");

        for (Ticket ticket : results) {
            ticket.displayTicket();
        }
    }

    private static void moveToInProgress() {

        String id = readRequired("Enter Ticket ID: ");

        boolean success = service.changeStatus(
                id,
                TicketStatus.IN_PROGRESS,
                ""
        );

        if (success) {
            System.out.println("Ticket moved to IN_PROGRESS.");
        } else {
            System.out.println("Invalid ticket ID or status transition.");
        }
    }

    private static void resolveTicket() {

        String id = readRequired("Enter Ticket ID: ");

        String resolution = readRequired("Enter resolution note: ");

        boolean success = service.changeStatus(
                id,
                TicketStatus.RESOLVED,
                resolution
        );

        if (success) {
            System.out.println("Ticket resolved successfully.");
        } else {
            System.out.println(
                    "Unable to resolve ticket. Make sure the ticket is IN_PROGRESS."
            );
        }
    }

    private static void closeTicket() {

        String id = readRequired("Enter Ticket ID: ");

        boolean success = service.changeStatus(
                id,
                TicketStatus.CLOSED,
                ""
        );

        if (success) {
            System.out.println("Ticket closed successfully.");
        } else {
            System.out.println(
                    "Unable to close ticket. Ticket must be RESOLVED first."
            );
        }
    }

    private static Category selectCategory() {

        while (true) {

            System.out.println("\nSelect Category:");
            System.out.println("1. Technical");
            System.out.println("2. Academic");
            System.out.println("3. Account");
            System.out.println("4. Infrastructure");
            System.out.println("5. Other");

            int choice = readInt("Choice: ");

            switch (choice) {

                case 1:
                    return Category.TECHNICAL;

                case 2:
                    return Category.ACADEMIC;

                case 3:
                    return Category.ACCOUNT;

                case 4:
                    return Category.INFRASTRUCTURE;

                case 5:
                    return Category.OTHER;

                default:
                    System.out.println("Invalid category. Try again.");
            }
        }
    }

    private static Priority selectPriority() {

        while (true) {

            System.out.println("\nSelect Priority:");
            System.out.println("1. Low");
            System.out.println("2. Medium");
            System.out.println("3. High");
            System.out.println("4. Critical");

            int choice = readInt("Choice: ");

            switch (choice) {

                case 1:
                    return Priority.LOW;

                case 2:
                    return Priority.MEDIUM;

                case 3:
                    return Priority.HIGH;

                case 4:
                    return Priority.CRITICAL;

                default:
                    System.out.println("Invalid priority. Try again.");
            }
        }
    }

    private static String readRequired(String message) {

        while (true) {

            System.out.print(message);

            String input = scanner.nextLine().trim();

            if (!input.isEmpty()) {
                return input;
            }

            System.out.println("This field cannot be empty.");
        }
    }

    private static int readInt(String message) {

        while (true) {

            System.out.print(message);

            try {
                return Integer.parseInt(scanner.nextLine().trim());

            } catch (NumberFormatException e) {

                System.out.println("Please enter a valid number.");
            }
        }
    }

    private static void addSampleData() {

        service.createTicket(
                new User("Chandana"),
                "Unable to Login",
                "Cannot login to the college portal.",
                Category.TECHNICAL,
                Priority.HIGH
        );

        service.createTicket(
                new User("Rahul"),
                "Assignment Issue",
                "Unable to submit assignment.",
                Category.ACADEMIC,
                Priority.MEDIUM
        );
    }
}