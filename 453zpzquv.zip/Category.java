public enum Category {
    TECHNICAL,
    ACADEMIC,
    ACCOUNT,
    INFRASTRUCTURE,
    OTHER
}