import java.util.ArrayList;
import java.util.List;

public class HelpdeskService {

    private List<Ticket> tickets = new ArrayList<>();
    private int nextTicketNumber = 1001;

    public Ticket createTicket(User user, String title,
                               String description,
                               Category category,
                               Priority priority) {

        String ticketId = "TKT-" + nextTicketNumber++;

        Ticket ticket = new Ticket(
                ticketId,
                user,
                title,
                description,
                category,
                priority
        );

        tickets.add(ticket);

        return ticket;
    }

    public List<Ticket> getAllTickets() {
        return tickets;
    }

    public Ticket findTicket(String ticketId) {

        for (Ticket ticket : tickets) {
            if (ticket.getTicketId().equalsIgnoreCase(ticketId)) {
                return ticket;
            }
        }

        return null;
    }

    public boolean updateTicket(String ticketId,
                                String title,
                                String description,
                                Category category,
                                Priority priority) {

        Ticket ticket = findTicket(ticketId);

        if (ticket == null) {
            return false;
        }

        if (ticket.getStatus() == TicketStatus.CLOSED) {
            return false;
        }

        ticket.updateTicket(title, description, category, priority);
        return true;
    }

    public boolean changeStatus(String ticketId,
                                TicketStatus newStatus,
                                String resolution) {

        Ticket ticket = findTicket(ticketId);

        if (ticket == null) {
            return false;
        }

        TicketStatus current = ticket.getStatus();

        if (!isValidTransition(current, newStatus)) {
            return false;
        }

        if (newStatus == TicketStatus.RESOLVED) {

            if (resolution == null || resolution.trim().isEmpty()) {
                return false;
            }

            ticket.setResolution(resolution);
        }

        ticket.setStatus(newStatus);

        return true;
    }

    private boolean isValidTransition(TicketStatus current,
                                      TicketStatus next) {

        if (current == TicketStatus.OPEN &&
            next == TicketStatus.IN_PROGRESS) {
            return true;
        }

        if (current == TicketStatus.IN_PROGRESS &&
            next == TicketStatus.RESOLVED) {
            return true;
        }

        if (current == TicketStatus.RESOLVED &&
            next == TicketStatus.CLOSED) {
            return true;
        }

        return false;
    }

    public List<Ticket> searchTickets(String keyword) {

        List<Ticket> results = new ArrayList<>();

        keyword = keyword.toLowerCase();

        for (Ticket ticket : tickets) {

            if (ticket.getTicketId().toLowerCase().contains(keyword)
                    || ticket.getUser().getName().toLowerCase().contains(keyword)
                    || ticket.getTitle().toLowerCase().contains(keyword)
                    || ticket.getCategory().toString().toLowerCase().contains(keyword)) {

                results.add(ticket);
            }
        }

        return results;
    }
}