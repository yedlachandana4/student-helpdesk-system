import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Ticket {

    private String ticketId;
    private User user;
    private String title;
    private String description;
    private Category category;
    private Priority priority;
    private TicketStatus status;
    private String resolution;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    private static final DateTimeFormatter FORMATTER =
            DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");

    public Ticket(String ticketId, User user, String title,
                  String description, Category category,
                  Priority priority) {

        this.ticketId = ticketId;
        this.user = user;
        this.title = title;
        this.description = description;
        this.category = category;
        this.priority = priority;
        this.status = TicketStatus.OPEN;
        this.resolution = "";

        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    public String getTicketId() {
        return ticketId;
    }

    public User getUser() {
        return user;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public Category getCategory() {
        return category;
    }

    public Priority getPriority() {
        return priority;
    }

    public TicketStatus getStatus() {
        return status;
    }

    public String getResolution() {
        return resolution;
    }

    public void updateTicket(String title, String description,
                             Category category, Priority priority) {

        this.title = title;
        this.description = description;
        this.category = category;
        this.priority = priority;
        this.updatedAt = LocalDateTime.now();
    }

    public void setStatus(TicketStatus status) {
        this.status = status;
        this.updatedAt = LocalDateTime.now();
    }

    public void setResolution(String resolution) {
        this.resolution = resolution;
        this.updatedAt = LocalDateTime.now();
    }

    public void displayTicket() {

        System.out.println("----------------------------------------");
        System.out.println("Ticket ID   : " + ticketId);
        System.out.println("Student     : " + user.getName());
        System.out.println("Title       : " + title);
        System.out.println("Description : " + description);
        System.out.println("Category    : " + category);
        System.out.println("Priority    : " + priority);
        System.out.println("Status      : " + status);

        if (!resolution.isEmpty()) {
            System.out.println("Resolution  : " + resolution);
        }

        System.out.println("Created     : " + createdAt.format(FORMATTER));
        System.out.println("Updated     : " + updatedAt.format(FORMATTER));
        System.out.println("----------------------------------------");
    }
}